#!/bin/bash

#######################################
# Author: Wayne Xing
# Version: v1.0.0
# Date: 2021-01-06
# Description: Our first script!
# Usage: ./hello-world-improved.sh
#######################################

# Print the text to the Terminal.
echo "Hello World!"
